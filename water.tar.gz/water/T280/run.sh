#!/bin/bash
# run.sh: the job for this folder.
#
# A day-1 stand-in for "gmx mdrun", so that nobody needs GROMACS yet.
# It reads md.mdp and writes md.log, temperature.xvg and density.xvg,
# the way a real run would. You do not need to read the rest of it.
#
# Use it inside a run folder, on the cluster:
#     bash run.sh

host=${DAY1_HOST:-$(hostname -s 2>/dev/null || hostname)}
now=${DAY1_DATE:-$(date '+%a %b %e %H:%M:%S %Y')}
end=${DAY1_END:-}
workdir=${DAY1_WD:-$(pwd)}
seed=${DAY1_SEED:-$RANDOM}
pause=${DAY1_PAUSE:-0.6}

if [ ! -f md.mdp ]; then
    echo "run.sh: there is no md.mdp in $(pwd)"
    echo "        cd into the run folder first, then: bash run.sh"
    exit 1
fi

if [ ! -d /nas_home ] && [ -z "${DAY1_ANYWHERE:-}" ]; then
    echo "run.sh: this computer is not the cluster."
    echo "        Copy the folder to mmkluster with scp -r and run it there."
    exit 1
fi

# Value of one option in md.mdp: "dt = 0.002 ; comment" gives 0.002.
mdp() {
    awk -F'=' -v key="$1" '
        { sub(/;.*/, "") }
        NF >= 2 {
            k = $1; gsub(/[ \t\r]/, "", k); gsub(/_/, "-", k)
            v = $2; gsub(/^[ \t]+|[ \t\r]+$/, "", v); split(v, part, /[ \t]+/)
            if (tolower(k) == key) val = part[1]
        }
        END { print val }' md.mdp
}

positive() {
    awk -v x="$1" 'BEGIN { exit !(x ~ /^[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$/ && x + 0 > 0) }'
}

dt=$(mdp dt)
nsteps=$(mdp nsteps)
temp=$(mdp ref-t)

for pair in "dt:$dt:0.002" "nsteps:$nsteps:250000" "ref-t:$temp:300"; do
    name=${pair%%:*}; rest=${pair#*:}; value=${rest%%:*}; example=${rest#*:}
    if ! positive "$value"; then
        echo "run.sh: cannot read '$name' in md.mdp (found: '$value')."
        echo "        The line should look like:  $name = $example"
        exit 1
    fi
done

length=$(awk -v d="$dt" -v n="$nsteps" 'BEGIN { printf "%g", d * n }')
if awk -v l="$length" 'BEGIN { exit !(l > 20000) }'; then
    echo "run.sh: $nsteps steps x $dt ps = $length ps. Day 1 runs are at most 20000 ps."
    exit 1
fi
if awk -v t="$temp" 'BEGIN { exit !(t < 250 || t > 400) }'; then
    echo "run.sh: ref-t = $temp K. This water box only works between 250 and 400 K."
    exit 1
fi

# Water is rigid: a time step above 0.002 ps makes the run blow up.
crash=0
awk -v d="$dt" 'BEGIN { exit !(d > 0.00201) }' && crash=1
last=$nsteps
if [ $crash = 1 ]; then
    last=$(awk -v d="$dt" -v n="$nsteps" 'BEGIN { s = int(6.25 / d); if (s > n) s = n; print s }')
fi

echo "                  :-) GROMACS - gmx mdrun, 2026.4 (-:"
echo
echo "Reading md.mdp:  dt = $dt ps   nsteps = $nsteps   ref-t = $temp K"
echo "Length of the run: $nsteps x $dt ps = $length ps"
echo "Starting mdrun on host $host"
echo
for i in 1 2 3 4 5 6 7 8 9 10; do
    [ $crash = 1 ] && [ $i -gt 5 ] && break
    step=$(awk -v s="$last" -v i=$i -v c=$crash 'BEGIN { printf "%d", s * i / (c ? 5 : 10) }')
    echo "step $step"
    sleep "$pause"
done

[ -n "$end" ] || end=$(date '+%a %b %e %H:%M:%S %Y')

awk -v dt="$dt" -v nsteps="$nsteps" -v T="$temp" -v crash=$crash -v last="$last" \
    -v seed="$seed" -v host="$host" -v now="$now" -v end="$end" -v wd="$workdir" '
function gauss() { return sqrt(-2 * log(1 - rand())) * cos(6.283185307 * rand()) }
function row(label, n,   i) { for (i = 1; i <= n; i++) printf "%15s", label[i] > LOG; printf "\n" > LOG }
function block(step, t, temp, rho, press,   ke, ep, lab, val) {
    ke = 0.5 * 5997 * 0.0083144626 * temp
    ep = -46800 + 50 * (T - 298) + 120 * gauss()
    printf "%15s%15s\n%15d%15.5f\n\n   Energies (kJ/mol)\n", "Step", "Time", step, t > LOG
    printf "%15s%15s%15s%15s%15s\n", "Potential", "Kinetic En.", "Total Energy", "Conserved En.", "Temperature" > LOG
    printf "%15.5e%15.5e%15.5e%15.5e%15.5e\n", ep, ke, ep + ke, ep + ke + 0.4 * t, temp > LOG
    printf "%15s%15s%15s\n", "Pressure (bar)", "Density", "Constr. rmsd" > LOG
    printf "%15.5e%15.5e%15.5e\n\n", press, rho, 0 > LOG
}
function header(file, what, unit, legend) {
    print "# This file was created " now > file
    print "# Created by:" > file
    print "#                    :-) GROMACS - gmx energy, 2026.4 (-:" > file
    print "#" > file
    print "# Command line:" > file
    print "#   gmx energy -f md.edr -o " file > file
    print "#" > file
    print "@    title \"GROMACS Energies\"" > file
    print "@    xaxis  label \"Time (ps)\"" > file
    print "@    yaxis  label \"(" unit ")\"" > file
    print "@TYPE xy" > file
    print "@ view 0.15, 0.15, 0.75, 0.85" > file
    print "@ legend on" > file
    print "@ legend box on" > file
    print "@ s0 legend \"" legend "\"" > file
}
BEGIN {
    srand(seed)
    LOG = "md.log"
    rho_eq = 760.047 + 1.88183 * T - 0.00367145 * T * T
    rho_start = 994.17                    # the box was equilibrated at 300 K
    sig_t = T * sqrt(2 / 5997)
    nstenergy = int(1 / dt + 0.5)         # energies every 1 ps
    nstlog = 10 * nstenergy               # md.log every 10 ps

    print "                      :-) GROMACS - gmx mdrun, 2026.4 (-:" > LOG
    print "" > LOG
    print "Executable:   /opt/gromacs-2026.4/bin/gmx" > LOG
    print "Working dir:  " wd > LOG
    print "Command line:" > LOG
    print "  gmx mdrun -deffnm md" > LOG
    print "" > LOG
    print "GROMACS version:     2026.4" > LOG
    print "Precision:           mixed" > LOG
    print "Running on 1 node with total 16 cores, 16 processing units" > LOG
    print "Hardware detected on host " host ":" > LOG
    print "  CPU info:" > LOG
    print "    Vendor: Intel" > LOG
    print "    Brand:  Intel(R) Xeon(R) CPU E5-2630 v3 @ 2.40GHz" > LOG
    print "" > LOG
    print "Input Parameters:" > LOG
    printf "   %-30s = %s\n", "integrator", "md" > LOG
    printf "   %-30s = %s\n", "dt", dt > LOG
    printf "   %-30s = %s\n", "nsteps", nsteps > LOG
    printf "   %-30s = %s\n", "nstenergy", nstenergy > LOG
    printf "   %-30s = %s\n", "nstlog", nstlog > LOG
    printf "   %-30s = %s\n", "cutoff-scheme", "Verlet" > LOG
    printf "   %-30s = %s\n", "coulombtype", "PME" > LOG
    printf "   %-30s = %s\n", "rcoulomb", "1" > LOG
    printf "   %-30s = %s\n", "rvdw", "1" > LOG
    printf "   %-30s = %s\n", "tcoupl", "V-rescale" > LOG
    printf "   %-30s = %s\n", "tau-t", "0.1" > LOG
    printf "   %-30s = %s\n", "ref-t", T > LOG
    printf "   %-30s = %s\n", "pcoupl", "C-rescale" > LOG
    printf "   %-30s = %s\n", "tau-p", "2" > LOG
    printf "   %-30s = %s\n", "ref-p", "1" > LOG
    printf "   %-30s = %s\n", "compressibility", "4.5e-05" > LOG
    print "" > LOG
    print "System: SPC/E water, 1000 molecules, 3000 atoms" > LOG
    print "" > LOG
    print "Started mdrun on rank 0 " now > LOG
    print "" > LOG

    if (crash) {
        block(0, 0, T + sig_t * gauss(), rho_start, 1 + 300 * gauss())
        for (s = last - 1; s <= last; s++) {
            printf "step %d: One or more water molecules can not be settled.\n", s > LOG
            print "Check for bad contacts and/or reduce the timestep if appropriate." > LOG
            print "Wrote pdb files with previous and current coordinates" > LOG
            print "" > LOG
        }
        msg = "-------------------------------------------------------\n"
        msg = msg "Program:     gmx mdrun, version 2026.4\n\n"
        msg = msg "Fatal error:\n"
        msg = msg sprintf("The system blew up: water molecules could not be settled at step %d\n", last)
        msg = msg sprintf("(time %g ps). The usual cause is a time step that is too large.\n", last * dt)
        msg = msg sprintf("dt in md.mdp is %s ps; with rigid water use dt = 0.002 ps or less.\n\n", dt)
        msg = msg "For more information and tips for troubleshooting, please check the GROMACS\n"
        msg = msg "website at https://manual.gromacs.org/current/user-guide/run-time-errors.html\n"
        msg = msg "-------------------------------------------------------"
        print msg > LOG
        print "" ; print msg
        for (k = 0; k < 2; k++) {
            pdb = sprintf("step%d%s.pdb", last, k ? "c" : "b")
            print "REMARK    coordinates at step " last (k ? " (current)" : " (before)") > pdb
            print "CRYST1   31.060   31.060   31.060  90.00  90.00  90.00 P 1           1" > pdb
            for (a = 1; a <= 30; a++)
                printf "ATOM  %5d %-4s SOL  %4d    %8.3f%8.3f%8.3f  1.00  0.00\n", a, (a % 3 == 1 ? " OW" : (a % 3 == 2 ? " HW1" : " HW2")), int((a + 2) / 3), 31 * rand(), 31 * rand(), 31 * rand() > pdb
            print "END" > pdb
            close(pdb)
        }
        exit 1
    }

    header("temperature.xvg", "Temperature", "K", "Temperature")
    header("density.xvg", "Density", "kg/m^3", "Density")
    nframes = int(nsteps * dt + 0.5)
    xt = 0; xr = 0; sum_t = 0; sum_r = 0; sum_p = 0
    for (i = 0; i <= nframes; i++) {
        t = i
        xt = 0.3 * xt + sqrt(1 - 0.09) * gauss()
        xr = 0.6 * xr + sqrt(1 - 0.36) * gauss()
        temp = T + sig_t * xt
        rho = rho_eq + (rho_start - rho_eq) * exp(-t / 15) + 4 * xr
        press = 1 + 250 * gauss()
        printf "%12.6f  %10.4f\n", t, temp > "temperature.xvg"
        printf "%12.6f  %10.4f\n", t, rho > "density.xvg"
        sum_t += temp; sum_r += rho; sum_p += press
        if (i % 10 == 0) block(int(t / dt + 0.5), t, temp, rho, press)
    }
    n = nframes + 1
    print "\t<======  ###############  ==>" > LOG
    print "\t<====  A V E R A G E S  ====>" > LOG
    print "\t<==  ###############  ======>" > LOG
    print "" > LOG
    printf "\tStatistics over %d steps using %d frames\n\n", nsteps + 1, n > LOG
    block(nsteps, nsteps * dt, sum_t / n, sum_r / n, sum_p / n)
    nsday = (360 + 15 * gauss()) * dt / 0.002
    wall = nsteps * dt / 1000 / nsday * 86400
    printf "%25s%13s%11s\n", "Core t (s)", "Wall t (s)", "(%)" > LOG
    printf "%12s%13.3f%13.3f%11.1f\n", "Time:", 16 * wall, wall, 1600 > LOG
    printf "%25s%13s\n", "(ns/day)", "(hour/ns)" > LOG
    printf "%-12s%13.3f%13.3f\n", "Performance:", nsday, 24 / nsday > LOG
    print "" > LOG
    print "Finished mdrun on rank 0 " end > LOG
}'
status=$?

if [ $status = 0 ]; then
    echo
    echo "Finished mdrun. New files in $(pwd):"
    echo "    md.log  temperature.xvg  density.xvg"
fi
exit $status
