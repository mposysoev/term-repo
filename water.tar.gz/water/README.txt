Water at four temperatures
==========================

Four simulations of the same box of 1000 SPC/E water molecules,
500 ps each, at 280, 300, 320 and 350 K.

    T280/  T300/  T320/  T350/      one folder per run

Each folder has:

    md.mdp            settings: time step, number of steps, temperature
    conf.gro          starting coordinates of all 3000 atoms
    topol.top         which molecules are in the box
    run.sh            the job script:  bash run.sh
    md.log            what the program wrote while it ran
    temperature.xvg   temperature vs time   (columns: ps, K)
    density.xvg       density vs time       (columns: ps, kg/m^3)

One of the four runs did not finish. Find out which one, and why.

In .xvg files, lines that start with # or @ are notes for plotting
programs. The numbers come after them.

The logs are short versions of GROMACS output, edited for day 1.
