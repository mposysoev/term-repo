import numpy as np

file_name = ""
data = np.genfromtxt(file_name).T
print(np.mean(data[1, :]))
